const product = require('../models/product');

exports.addproduct = async (req, res) => {
  // const banner = req.files;
  try {
    // const link = req.file.location;
    // console.log(link);

    const { name, link, description, price, size, color, productCategory, discountPercent, highlights } = req.body;
    console.log({ name, link, description, price, size, color, productCategory, highlights });
    const discountedPrice = price - Math.ceil(price * (discountPercent / 100));
    if (!(name && link && price && description)) {
      return res.status(400).json({
        message: "please fill all the fields"
      });
    }
    const addBanner = await product.create({ name, link, description, price, discountedPrice, size, color, highlights });
    res.status(200).json({
      msg: "product successfully added",
      data: addBanner,
      status: true,
    });
  } catch (error) {
    res.status(400).json({
      message: error.message
    })
  }
};

exports.getProducts = async (req, res) => {
  try {
    let queryObj = {};
    if (req.query.color) {
      queryObj.color = req.query.color;
    }
    if (req.query.size) {
      queryObj.size = req.query.size;
    }
    if (req.query.productCategory) {
      queryObj.productCategory = req.query.productCategory;
    }
    const getproduct = await product.find();
    if (getproduct.length === 0) {
      return res.status(204).json({
        message: "product not found"
      });
    }
    res.status(200).json({ status: "success", data: getproduct });
  } catch (error) {
    console.log(error);
    res.status(500).send({ error: error.message });

  }
};


exports.editProduct = async (req, res) => {
  try {

    const { name, index, link, description, price, productCategory, addSize, removeSize, removeColor, addColor, averageRating, highlights } = req.body;
    if (addSize || addColor || name || index || productCategory || link || description || averageRating || price || highlights) {
      var updatedProduct = await product.findOneAndUpdate(
        { _id: req.params.id }, {
        $set: { name, index, link, description, price, productCategory, highlights, averageRating },
        $addToSet: {
          color: addColor,
          size: addSize
        }
      }, { new: true });
      console.log(updatedProduct);

    }
    if (removeSize || removeColor) {
      var updatedProduct = await product.findOneAndUpdate(
        { _id: req.params.id }, {
        $set: { name, index, link, description, price, highlights, averageRating },
        $pull: {
          color: { $in: removeColor },
          size: { $in: removeSize }
        }
      }, { new: true });
      console.log(updatedProduct);
    }


    res
      .status(200)
      .json({ msg: "product successfully Updated", data: updatedProduct });
  } catch (error) {
    console.log(error);
  }
};

exports.getProduct = async (req, res) => {
  try {
    const result = await product.findById(req.params.id);
    if (!result) {
      return res.status(204).json({
        message: "products not found"
      });
    }
    res.status(200).json({ status: "success", data: result });
  } catch (err) {
    console.log(err);
    res.status(500).send({ error: err.message });
  }
};

exports.deleteProduct = async (req, res) => {
  try {
    const result = await product.findByIdAndDelete(req.params.id);
    if (!result) {
      return res.status(204).json({
        message: "product not found"
      });
    }
    res.status(200).send({
      msg: "product  deleted successfully",
      status: true,
    });
  } catch (error) {
    res.send(500).json({
      status: "Failed",
      message: error.message,
    });
  }
};

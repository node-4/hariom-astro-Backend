// const multer = require('multer');
// const multerS3 = require('multer-s3');
// // const AWS = require('aws-sdk');
// require('dotenv').config();
// // const s3 = new AWS.S3({
// //     // accessKeyId: process.env.AWS_ACCESS_KEY,
// //     // secretAccessKey: process.env.AWS_ACCESS_KEY
// //     accessKeyId: "S07hsgAHLhYa6YJ/IWKZxwbRKlTEN8XZd2JWJ852",
// //     secretAccessKey: "AKIASRY3AQTBAV37WSW7"
// // });

// const s3Config = new AWS.S3({
//     accessKeyId: "AKIASRY3AQTBAV37WSW7",
//     secretAccessKey: "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",
//     Bucket: "flyweisimages",
// });
// module.exports = multer({
//     storage: multerS3({
//         s3: s3Config,
//         ACL: 'public-read',
//         ContentType: ["file/jpeg", "file/jpg"],
//         bucket: 'flyweisimages',
//         metadata: (req, file, cb) => {
//             console.log("Image Uploaded ")
//             console.log(file.originalname)
//             console.log(req.file)
//             cb(null, { fieldName: file.fieldname })

//         },
//         key: (req, file, cb) => {
//             cb(null, Date.now().toString() + '-' + file.originalname)
//         }
//     })
// });
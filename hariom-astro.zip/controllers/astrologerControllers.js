const bookidgen = require("bookidgen");
var newOTP = require('otp-generators')
// const Banner = require('../models/Banner')
const moment = require("moment");
// const product = require('../models/product')
const { encrypt, compare } = require("../services/crypto");
const verifySid = "VA84bc752a91abcf7df9f31c76832bafff";
const User = require("../models/User");
const Blog = require('../models/blog')
const jwt = require("jsonwebtoken");
const JWTkey = "rubi";
const bcrypt = require("bcryptjs");
const astrologer = require('../models/astrologer');
const fees = require("../models/fees_Models");
const review = require('../models/review');
const feedback = require("../models/feedback");
const Wallet = require("../models/wallet");
const wallet = require("../models/wallet");


const sendSMS = async (to, otp) => {
  const from = "+19287568632";
  await client.messages
    .create({
      body: otp,
      from: from,
      to: to,
    })
    .then((message) => {
      console.log(message.sid);
      return message;
    });
};


exports.sendOTP = async (req, res) => {

};

// exports.verifyOTP = async (req, res) => {
//   await client.verify.v2
//     .services(verifySid)
//     .verificationChecks.create({
//       to: `+91${req.body.mobile}`,
//       code: req.body.otp,
//     })
//     .then((data) => {
//       res.status(200).send({
//         status: data.status,
//       });
//       console.log("verified! 👍");
//     })
//     .catch((err) => {
//       res.status(401).json({
//         message: "Wrong OTP entered!",
//       });
//       console.log("wrong OTP !!");
//     });
// };

exports.signUpUser = async (req, res) => {

  const { firstName, lastName, password, confirmpassword, gallery, address, email, mobile, country, state, district, pincode, highestQualification, collegeOrInstitute, passingYear, govDocument, language, rashi, desc, skills, specification, fees, rating, link, aboutMe, gender, dailyhoures, experience } = req.body;
  console.log(req.body);

  // Check if user already exist
  const Existing = await astrologer.findOne({ mobile });
  if (Existing) {
    return res.status(402).send({ message: ` ${mobile} already exists` });
  }
  const emailRegistered = await astrologer.findOne({ email });
  if (emailRegistered) {
    return res.status(402).send({ message: ` ${email}` + " already exists" });
  }
  if (password !== confirmpassword) {
    res.status(401).json({ message: "Password is not match " })
  }
  encryptedPassword = await bcrypt.hash(password, 10);
  const referCode = newOTP.generate(10, { alphabets: true, upperCase: true, specialChar: false });
  const hashedPassword = await encrypt(password);
  const confirmPassword = await encrypt(confirmpassword)
  const otpGenerated = Math.floor(100 + Math.random() * 9000);
  const discountedFee = req.body.discountedFee ? req.body.discountedFee : fees;
  try {
    const newUser = await astrologer.create({
      firstName, lastName, address, gallery, referCode, email, mobile, country, discountedFee, state, district, pincode, highestQualification, collegeOrInstitute, passingYear, govDocument, language, rashi, desc, skills, specification, fees, rating, link, aboutMe, gender,
      password: hashedPassword,
      confirmpassword: confirmPassword,
      otp: otpGenerated,
      dailyhoures: parseInt(dailyhoures),
      experience: parseInt(experience)
    });

    const astro = await astrologer.findOne({ referCode: req.body.referCode });
    const user1 = await User.findOne({ referCode: req.body.referCode });
    if (astro) {
      const id = astro._id || user1._id;
      const user = await wallet.findOne({ userId: id });
      user.balance += 200;
      await user.save();
    }


    const w = await Wallet.create({ userId: newUser._id, user: newUser._id });
    // sendSMS(`+91${mobile_Number}`, otpGenerated)
    newUser.wallet = w;
    await newUser.save();
    return res.status(201).send({
      message: "signed Up successfully",
      data: newUser
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: error.message });
  }
};



exports.verifyOTP = async (req, res) => {
  try {
    const data = await astrologer.findOne({ otp: req.body.otp });
    if (!data) {
      return res.status(401).json({
        message: "Your Otp is Wrong"
      })
    } else {
      res.status(400).json({
        message: "Otp verify"
      })
    }
  } catch (err) {
    res.status(400).json({
      message: err.message
    })
  }
}
// SignIn 
exports.loginWithMobile = async (req, res) => {
  try {
    const user = await astrologer.findOne({ mobile: req.body.mobile });
    if (!user) {
      return res.status(404).send({ message: "you are not registered" });
    }
    const otpGenerated = Math.floor(100 + Math.random() * 9000);
    await astrologer.findOneAndUpdate({ mobile: req.body.mobile }, { otp: otpGenerated }, { new: true });
    res.status(200).send({ userId: user._id, otp: otpGenerated });

  } catch (err) {
    console.log(err.message);
    res.status(400).send({ message: err.message });
  }
};
exports.verifyMobileOtp = async (req, res) => {
  try {
    const user = await astrologer.findById(req.params.id);
    // console.log(user);
    if (!user) {
      return res.status(404).send({ message: "you are not found" });
    }
    if (user.otp != req.body.otp) {
      return res.status(400).send({ message: "Invalid OTP" });
    }
    const accessToken = jwt.sign(
      { user_id: user._id },
      JWTkey,
      (err, token) => {
        if (err) return res.status(400).send("Invalid Credentials");
        res.status(200).send({ token, user });
      }
    );

  }
  catch (error) {
    console.log(error.message);
    res.status(400).send({ error: error.message });
  }
}
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!(email && password)) {
      res.status(400).send("email and password are required");
    }

    const user = await astrologer.findOne({ email });

    if (!user)
      res.status(400).json({
        message: "email is not registered",
      });
    const isPassword = await compare(password, user.password)
    if (isPassword) {
      jwt.sign(
        { user_id: user._id },
        JWTkey,
        (err, token) => {
          if (err) return res.status(400).send("Invalid Credentials");
          res.status(200).send({ user, token });
        }
      );
    }
  } catch (err) {
    console.log(err);
  }
};


exports.ViewDataProfiles = async (req, res) => {
  try {
    const getDetails = await astrologer.findById(req.params.id);
    if (!getDetails) {
      res.status(400).json({ message: "Enter the correct id", status: false });
    } else {
      res.status(200).json({
        message: "User Details is Created successfully",
        data: getDetails,
        status: true,
      });
    }
  } catch (error) {
    res.status(400).json({ message: error.message, status: false });
  }
};

exports.SearchAstroNameLangSkills = async (req, res) => {
  const search = req.params.key;
  try {
    const student = await astrologer.find({
      $or: [
        { firstName: { $regex: search, $options: "i" } },
        { lastName: { $regex: search, $options: "i" } },
        { Skills: { $regex: search, $options: "i" } },
        { Languages: { $regex: search, $options: "i" } },
      ],
    });
    if (student.length == 0) {
      res.json({ message: "Data is not Found", status: false });
    } else {
      res.json({
        message: " Data  is found Successfully",
        student: student,
        status: true,
      });
    }
  } catch (error) {
    res.json({ message: error.message, status: false });
  }
};
exports.getAstrolgerById = async (req, res) => {
  try {
    const getDetails = await astrologer.findById(req.params.id).lean();
    // .select({ _id: 1, firstName: 1, lastName: 1, skills: 1, aboutMe: 1, language: 1, specification: 1 });
    if (!getDetails) {
      res.status(400).json({ message: "Enter the correct id", status: false });
    }
    res.status(200).json({

      data: getDetails,
      status: true,
    });
  } catch (error) {
    console.log(error.message);
    res.status(400).json({ message: error.message, status: false });
  }
};

exports.updateAstrologer = async (req, res) => {
  try {
    const { addLanguages, addSkills, discountedFee, addSpecification, removeLanguages, removeSkills, removeSpecification, fees, aboutMe, consultationMinutes
    } = req.body;

    if (addLanguages || addSkills || discountedFee || addSpecification || fees || aboutMe || consultationMinutes) {
      await astrologer.findOneAndUpdate(
        { _id: req.params.id },
        {
          $set: { fees: req.body.fees, aboutMe: req.body.aboutMe, discountedFee: discountedFee, consultationMinutes: consultationMinutes },
          $push: {
            language: { $each: addLanguages }
          },
          $push: {
            skills: { $each: req.body.addSkills }
          },
          $addToSet: { specification: addSpecification },
        },
        { new: true }
      );
      console.log("add");
    }
    if (removeLanguages || removeSkills || removeSpecification) {

      await astrologer.findOneAndUpdate(
        { _id: req.params.id },
        {
          $pull: {
            language: { $in: removeLanguages },
            skills: { $in: removeSkills },
          },
        },
        // {
        //   $pull: {
        //     language: { $in: removeLanguages },
        //     skills: { $in: removeSkills },
        //     specification: { $in: removeSpecification }
        //   },
        // },
        { new: true }
      );
      console.log("remove");
    }

    res.json({
      message: "profile updated successfully",
      status: true,
    });

  } catch (err) {
    console.log(err.message);
    res.status(500).send(err.message);
  }
};

exports.getAllBlogs = async (req, res) => {
  try {
    const blogs = await Blog.find();
    res.status(200).json({
      status: "success",
      data: blogs,
    });
  } catch (err) {
    res.status(400).json({
      status: "failure",
      message: err.message,
    });
  }
};

//Delete User--
exports.deleteAstroName = async (req, res) => {
  try {
    const DeleteUser = await astrologer.findByIdAndDelete({
      _id: req.params.id
    });
    if (!DeleteUser) {
      res.json({ message: "Enter the corret User  Name", status: false });
    } else {
      res
        .status(200)
        .json({ message: "User removed successfully", status: true });
    }
  } catch (error) {
    res.status(400).json({ message: error.message, status: false });
  }
};


exports.deleteLanguages = async (req, res) => {
  try {
    const DeleteUser = await astrologer.findOneAndDelete({
      $or: [{ Languages: { $regex: search, $options: "i" } }],
    });
    if (!DeleteUser) {
      res.json({ message: "Enter the corret User Languages", status: false });
    } else {
      res
        .status(200)
        .json({ message: "Languages removed successfully", status: true });
    }
  } catch (error) {
    res.status(400).json({ message: error.message, status: false });
  }
};

exports.GetAllAstro = async (req, res) => {
  try {
    // const users = await astrologer.find();
    const astro = await astrologer.find()
    if (!astro || astro.length === 0) {
      return res.status(400).json({ message: "astrologer not found" });
    }

    res.status(200).json({
      status: "success",
      data: astro
    });
  } catch (err) {
    res.status(400).json({
      status: "failure",
      message: err.message,
    });
  }
}

exports.getastroById = async (req, res) => {
  try {
    // const users = await astrologer.find();
    const astro = await astrologer.findById(req.params.id).lean();
    if (!astro) {
      return res.status(400).json({ message: "astrologer not found" });
    }

    res.status(200).json({
      status: "success",
      data: astro
    });
  } catch (err) {
    res.status(400).json({
      status: "failure",
      message: err.message,
    });
  }
}


exports.updateAstro = async (req, res) => {
  try {
    const { firstName, lastName, password, confirmpassword, address, email, mobile, country, state, district, pincode, highestQualification, collegeOrInstitute, passingYear, govDocument, language, rashi, desc, skills, specification, fees, rating, link, aboutMe, gender, dailyhoures, experience } = req.body;
    await astrologer.findByIdAndUpdate({ _id: req.params.id }, { firstName, lastName, password, confirmpassword, address, email, mobile, country, state, district, pincode, highestQualification, collegeOrInstitute, passingYear, govDocument, language, rashi, desc, skills, specification, fees, rating, link, aboutMe, gender, dailyhoures, experience }, { new: true });
    res.status(200).json({
      message: "Updated"
    });
  } catch (err) {
    console.log(err);
    res.state(400).json({
      err: err.message
    })
  }
}


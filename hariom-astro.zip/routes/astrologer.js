const router = require("express").Router();
const { isAuthenticated } = require("../controllers/auth.controller");
const astroControllers = require('../controllers/astrologerControllers');
const admin = require("../controllers/admin");
const product = require("../controllers/productControllers");
const terms = require("../controllers/terms.controller");
//Blogs
router.get("/blogs/:id", admin.ViewDataBlogs);
router.get("/blogs", admin.GetBlogs);

//products
router.get("/products/:id", product.getProduct);
router.get("/products", product.getProducts);

//profile
router.get("/profile/:id", astroControllers.getAstrolgerById);
router.put("/profile/:id", astroControllers.updateAstrologer);


// router.post('/sendOTP', astroControllers.sendOTP);
// router.post('/verifyOTP', astroControllers.verifyOTP);
router.post('/signup', astroControllers.signUpUser);
router.post('/login', astroControllers.login);
router.post('/verify', astroControllers.verifyOTP)
router.post('/loginwithmobile', astroControllers.loginWithMobile);
router.post('/verifymobileotp/:id', astroControllers.verifyMobileOtp);
router.get('/view/:id', astroControllers.ViewDataProfiles);
router.get('/search/:key', isAuthenticated, astroControllers.SearchAstroNameLangSkills);
router.get('/blog', astroControllers.getAllBlogs);
router.delete("/removed/:id", isAuthenticated, astroControllers.deleteAstroName);
router.delete("/remove-language", isAuthenticated, astroControllers.deleteLanguages)
router.get('/all', astroControllers.GetAllAstro);
router.put('/update/:id', isAuthenticated, astroControllers.updateAstro);
router.get('/:id', astroControllers.getastroById);

//Terms
router.get("/products/:id", product.getProduct);
router.get("/products", product.getProducts);




module.exports = router;
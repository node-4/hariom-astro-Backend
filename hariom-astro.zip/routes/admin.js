const express = require("express");
const router = express.Router();
const admin = require("../controllers/admin");
const { isAuthenticated } = require("../controllers/auth.controller");
const astroControllers = require('../controllers/astrologerControllers')
const app = require("express");
const path = require("path");
var multer = require("multer");
const notificationControllers = require('../controllers/notificationControllers');
const User = require("../models/User");
const UserControllers = require('../controllers/userController');
const AstroFeeback = require('../controllers/astroFeedback');
const testimonalControllers = require('../controllers/testimonial');
const product = require("../controllers/productControllers");
const uploads3 = require("../controllers/upload");
const terms = require("../controllers/terms.controller");
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "public/images");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});

var upload = multer({ storage: storage });

router.post("/login-admin", admin.login);
router.post("/signup", admin.signUpUser);
router.post(
  "/user-blog",
  upload.single("myField"),
  isAuthenticated,
  admin.postuserBlogs
);
router.get("/get-blogs/:id", isAuthenticated, admin.ViewDataBlogs);
router.patch(
  "/edit-user-blog/:id",
  upload.single("myField"),
  isAuthenticated,
  admin.UpdateBlogs
);


router.get('/allusers/', isAuthenticated, UserControllers.getAllUsers);
router.delete('/userdelete/:user_Name', isAuthenticated, UserControllers.deleteUserName)
// Add Charges Router 
router.post('/fees/:id', isAuthenticated, admin.AddChargesofAstro);
router.get('/fees', isAuthenticated, admin.GetAllFessDetails);
router.delete('/fees', isAuthenticated, admin.DeleteFeedetails);
router.put('/fees', isAuthenticated, admin.UpdateFees);
router.get('/fees/:id', isAuthenticated, admin.GetFeesByAstroId)

//blogs
router.delete("/remove-blog/:id", isAuthenticated, admin.RemovedBlogs);
router.post("/blogs", admin.postuserBlogs);
router.put("/blogs/:id", admin.UpdateBlogs);
router.get("/blogs/:id", admin.ViewDataBlogs);
router.get("/blogs", admin.GetBlogs);

//Products
router.delete("/products/:id", product.deleteProduct);
router.post("/products", product.addproduct);
router.put("/products/:id", product.editProduct);
router.get("/products/:id", product.getProduct);
router.get("/products", product.getProducts);


router.post("/add-feedback", isAuthenticated, admin.UserFeedback);
router.get("/view-feedback", isAuthenticated, admin.ViewAllFeedback);
// router.get("feedbacks", isAuthenticated,)
// Astrologer 
router.get('/astro', isAuthenticated, admin.allAstro);
router.post('/astro/', isAuthenticated, astroControllers.signUpUser);
router.delete('/astro/:id', isAuthenticated, astroControllers.deleteAstroName);
router.put('/astro/:id', isAuthenticated, astroControllers.updateAstro);


//Add Notification 
router.post('/notification', notificationControllers.AddNotification);
router.get('/notification', notificationControllers.getNotification);
router.put('/notification', notificationControllers.updateNotification);
router.delete('/notification', notificationControllers.deleteNotification);


//testimaonal 
router.post('/testimonial', testimonalControllers.AddTestimonial);
router.get('/testimonial', testimonalControllers.getTestimonial);
router.delete('/testimonial/:id', testimonalControllers.deleteTestmoial);

//terms
router.post("terms", terms.create);
router.put("terms/:id", terms.update);
router.get("terms/:id", terms.getId);
router.get("term", terms.get);
router.delete("terms/:id", terms.delete);



module.exports = router;

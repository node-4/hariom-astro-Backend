const mongoose = require("mongoose");
const productSchema = new mongoose.Schema(
  {
    name: {
      type: String
    },
    link: {
      type: [String],
      trim: true,
    },
    price: {
      type: Number,
    },
    discountedPrice: {
      type: Number,
      default: 0
    },
    description: {
      type: String
    },
    size: {
      type: [String],
    },
    color: {
      type: [String],
    },
    productCAtegory: {
      type: String,
    },
    averageRating: {
      type: Number,
      default: 0
    },
    discountPercent: {
      type: String,
    },
    review: {
      type: [mongoose.SchemaTypes.ObjectId],
      ref: "ProductReview"
    },
    highlights: {
      type: String
    }
  },
  { timestamps: true }
);
module.exports = mongoose.model("product", productSchema);

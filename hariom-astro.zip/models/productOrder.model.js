const mongoose = require('mongoose');

const schema = new mongoose.Schema({
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "userId"
    },
    product: {
        type: [mongoose.Schema.Types.ObjectId],
        ref: "product"
    },
    address: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Address"
    },
    totalPrice: {
        type: Number,
    },
    orderStatus: {
        type: String,
        default: "Pending"
    }
}, { timestamps: true });

module.exports = mongoose.model('CartProductOrder', schema);
const mongoose = require("mongoose");

const AstrologerSchema = new mongoose.Schema({
  firstName: {
    type: String,
    required: false,
  },
  lastName: {
    type: String,
    required: false,
  },
  created: {
    type: String,
    default: new Date().toISOString(),
  },
  password: {
    type: String,
    required: false,
  },
  confirmpassword: {
    type: String,
    required: false,
  },
  address: {
    type: String,
    required: false
  },
  email: {
    type: String,
    required: false,
  },
  mobile: {
    type: String,
    required: false
  },
  country: {
    type: String,
    required: false
  },
  gender: {
    type: String,

  },
  collegeOrInstitute: {
    type: String,
  },
  passingYear: {
    type: String,
  },
  highestQualification: {
    type: String,
    required: false
  },
  govDocument: {
    type: String,
  },

  state: {
    type: String,
    required: false
  },
  district: {
    type: String,
    required: false
  },
  referCode: {
    type: String,
  },
  pincode: {
    type: String,
  },
  otp: {
    type: String
  },
  language: {
    type: [String],
    default: [],
  },

  desc: {
    type: String
  },
  rashi: {
    type: String
  },
  skills: {
    type: [String],
    default: [],
  },
  specification: {
    type: [String],
    default: [],
  },
  averageRating: {
    type: Number,
    default: 0
  },
  review: {
    type: [mongoose.SchemaTypes.ObjectId],
    ref: "Review",
    default: []
  },
  fees: {
    type: String,
  },
  discountedFee: {
    type: Number,

  },
  gallery: {
    type: [String],
    default: [],
  },
  aboutMe: {
    type: String
  },
  // dailyhoures: {
  //   type: String,
  //   required: false
  // },
  experience: {
    type: String,
    require: false
  },
  video: {
    type: [String],
  }
}, { timestamps: true });

module.exports = mongoose.model("astrologer", AstrologerSchema);
